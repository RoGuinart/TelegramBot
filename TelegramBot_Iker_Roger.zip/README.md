# Alchemy Bot: Iker Sánchez & Roger Guinart

Bot de Telegram programat en Python com a projecte per a 2n de DAM, mòdul M13.
Aquest bot utilitza una base de dades guardada a remotemysql.com

El nostre bot és un joc: a partir de quatre elements bàsics (foc, aigua, terra, aire), es troben combinacions que creen nous elements. Per exemple, combinar aigua i aire crea un núvol. En aquesta versió hi ha 68 elements. Majoritàriament, només hi ha una combinació per cada element.
